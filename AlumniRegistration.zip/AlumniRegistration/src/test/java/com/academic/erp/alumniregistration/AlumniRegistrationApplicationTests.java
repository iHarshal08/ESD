package com.academic.erp.alumniregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlumniRegistrationApplicationTests {

    @Test
    void contextLoads() {
    }

}
